# Data Analysis Workflow

This document outlines the standard workflow for analyzing data from the SDS3 dataset.

## Prerequisites

- Python 3.7+ with pandas, numpy, and matplotlib
- R 4.0+ with tidyverse packages

## Analysis Steps

1. Data preprocessing (see utilities/data_preprocessing.py)
2. Quality control checks
3. Statistical analysis (see analysis_scripts/analyze_data.py)
4. Visualization (see analysis_scripts/plot_results.R)
5. Results interpretation

## Output Files

All analysis results should be stored in the corresponding site's results directory.
